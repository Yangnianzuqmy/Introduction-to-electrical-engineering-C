import sys
import urllib2
from bs4 import BeautifulSoup

def parseURL(content):
    soup=BeautifulSoup(content)
    imgset = set()
    for i in soup.findAll('a'):
        if str(i['href'])[:4] == 'http' or str(i['href'])[:2] == '//':
            imgset.add(i['href'])
    return imgset

def write_outputs(urls, filename):
    with open(filename, 'w') as f:
        for url in urls:
            f.write(str(url))
            f.write('\n')


def main():
    url = 'http://www.baidu.com'
    if len(sys.argv) > 1:
        url = sys.argv[1]
    content = urllib2.urlopen(url).read()
    urls = parseURL(content)
    write_outputs(urls, 'res1.txt')


if __name__ == '__main__':
    main()

