import sys
import urllib2
from bs4 import BeautifulSoup


def parseIMG(content):
    soup=BeautifulSoup(content)
    imgset = set()
    for i in soup.findAll('img'):
        if str(i['src'])[:4] == 'http' or str(i['src'])[:2] == '//':
            imgset.add(i['src'])
    return imgset


def write_outputs(imgs, filename):
    with open(filename, 'w') as f:
        for img in imgs:
            f.write(str(img))
            f.write('\n')


def main():
    img = 'http://www.baidu.com'
    if len(sys.argv) > 1:
        img = sys.argv[1]
    content = urllib2.urlopen(img).read()
    imgs = parseIMG(content)
    write_outputs(imgs, 'res2.txt')


if __name__ == '__main__':
    main()


