import sys
import urllib2
import re
import urlparse
import codecs
from bs4 import BeautifulSoup
reload(sys)
sys.setdefaultencoding('utf-8')

def parseQiushibaikePic(content):
    soup=BeautifulSoup(content,features="html.parser")
    docs={}
    nextPage=''
    for i in soup.findAll('div',{'id':re.compile('^qiushi_tag_')}):
        imgurl = []
        tmp=i['id'].split('_')[-1]
        docs[tmp]={}
        content_tmp=str(i)
        if "class=\"content\""not in content_tmp:
            docs[tmp]['content']='None'
        else:
            docs[tmp]['content']=content_tmp.split('\n\n\n')[1].split('</span>')[0].replace("<br/>",' ')
        if "class=\"thumb\""not in content_tmp:
            imgurl.append("None")
        else:
            for k in i.findAll('div',{'class':re.compile('^thumb')}):
                imgurl.append(k.img['src'])
        docs[tmp]['imgurl']=imgurl
    for i in soup.findAll('span', {'class': re.compile('^current')}):
        nextPage=i.parent.nextSibling.nextSibling.a['href']
    return docs,nextPage


def write_outputs(docs, filename):
    with open(filename, 'w') as f:
        for item in docs:
            for i in docs[item]['imgurl']:
                f.write(i)
                f.write('\t')
            f.write(docs[item]['content'])
            f.write('\n')

def main():
    url="https://www.qiushibaike.com/"
    if len(sys.argv) > 1:
        url = sys.argv[1]
    req=urllib2.Request(url,None,{'User-agent':'Custom User Agent'})
    content = urllib2.urlopen(req).read()
    infos,nextPage= parseQiushibaikePic(content)
    nextPage=urlparse.urljoin(url,nextPage)
    write_outputs(infos, 'res3.txt')

if __name__ == '__main__':
    main()


