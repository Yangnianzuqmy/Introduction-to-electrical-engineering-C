import cv2
import matplotlib.pyplot as plt

def colour_img(object):
    img = cv2.imread(object,cv2.IMREAD_COLOR)

    blue=0
    green=0
    red=0

    size=img.shape#gaodu,kuandu,


    for i in range(size[0]):
        for j in range(size[1]):
            blue+=img[i][j][0]
            green+=img[i][j][1]
            red+=img[i][j][2]

    sum=blue+green+red

    result=[]
    result.append(float(blue)/sum)
    result.append(float(green)/sum)
    result.append(float(red)/sum)

    print "For %s :"%(object)
    print "Percentage of Blue : %s"%(result[0])
    print "Percentage of Green : %s"%(result[1])
    print "Percentage of Red : %s\n"%(result[2])

    return result

def colour_matplot(object):
    name_list = ['Blue','Green','Red']
    x =list(range(3))
    plt.bar(x, colour_img(object),tick_label = name_list,color='bgr')
    plt.legend()
    plt.xlabel('colour')
    plt.ylabel('value')
    plt.title("The Colour Histogram of %s"%(object))
    plt.show()

img1="img1.png"
img2="img2.png"

colour_matplot(img1)
colour_matplot(img2)


