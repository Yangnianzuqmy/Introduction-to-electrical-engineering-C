import cv2
import matplotlib.pyplot as plt
import math

def grayscale_img(object):
    img = cv2.imread(object,cv2.IMREAD_GRAYSCALE)

    elem=[0]*256
    result=[]

    size=img.shape

    for i in range(size[0]):
        for j in range(size[1]):
            elem[img[i][j]]+=1

    area=size[0]*size[1]

    for i in range(256):
        result.append(float(elem[i])/area)

    return result

def grayscale_gradient_img(object):
    img = cv2.imread(object,cv2.IMREAD_GRAYSCALE)

    size=img.shape

    elem=[0]*361
    result=[]

    for i in range(1,size[0]-1):
        for j in range(1,size[1]-1):
            direction_x=img[i+1,j]*1.0-img[i-1,j]*1.0
            direction_y=img[i,j+1]*1.0-img[i,j-1]*1.0
            tmp=float(math.sqrt(direction_x**2+direction_y**2))
            elem[int(tmp)]+=1

    area=(size[0]-2)*(size[1]-2)

    for i in range(361):
        result.append(float(elem[i])/area)

    return result

def gray_matplot(object):
    x =list(range(256))
    plt.bar(x, grayscale_img(object),color='k')
    plt.legend()
    plt.xlabel('value')
    plt.ylabel('percentage')
    plt.title("The Grayscale Histogram of %s"%(object))
    plt.show()

def gray_gradient_matplot(object):
    x =list(range(361))
    plt.bar(x, grayscale_gradient_img(object),color='k')
    plt.legend()
    plt.xlabel('value')
    plt.ylabel('percentage')
    plt.title("The Grayscale-Gradient Histogram of %s"%(object))
    plt.show()

img1="img1.png"
img2="img2.png"
gray_matplot(img1)
gray_matplot(img2)
gray_gradient_matplot(img1)
gray_gradient_matplot(img2)
