# coding=utf-8
import cv2
import math
from math import *
import numpy as np

def graying(object):
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]
    img2 = cv2.imread(object, cv2.IMREAD_COLOR)
    for i in range(height):
        for j in range(width):
            img[i, j] = 0.114 * int(img2[i, j][0]) + 0.587 * int(img2[i, j][1]) + 0.299 * int(img2[i, j][2])
    return img
def my_Gaussian_Blur(object1,object2):
    img = cv2.imread(object1, 0)
    height, width = img.shape[:2]
    sigma = 1
    sum = 0
    gaussian = np.zeros([3, 3])
    for i in range(3):
        for j in range(3):
            gaussian[i, j] = math.exp(-1 / 2 * (np.square(i - 2) / np.square(sigma) + (np.square(j - 2) / np.square(sigma)))) / (2 * math.pi * sigma * sigma)
        sum = sum + gaussian[i, j]
    gaussian = gaussian / sum  # 归一化
    gray=object2
    for i in range(1, width - 1):
        for j in range(1, height - 1):
            try:
                object2[i, j] = np.sum(gray[i - 1:i + 2, j - 1:j + 2] * gaussian)  # 与高斯矩阵卷积实现滤波
            except:
                pass
    return object2
def calculation(object1,object2,operator):
    img = cv2.imread(object1, 0)
    height, width = img.shape[:2]
    area = width * height
    P = [0] * area
    Q = [0] * area
    M = [0] * area
    angle = [0] * area
    if operator=="Canny":
        for i in range(height - 1):
            for j in range(width):
                P[i * width + j] = float(int(object2[i, min(j + 1, width - 1)]) - int(object2[i, j]) + int(
                    object2[min(i + 1, height - 1), min(j + 1, width - 1)]) - int(object2[min(i + 1, height - 1), j])) / 2
                Q[i * width + j] = float(int(object2[i, j]) - int(object2[min(i + 1, height - 1), j]) + int(object2[i, min(j + 1, width - 1)]) - int(object2[min(i + 1, height - 1), min(j + 1, width - 1)])) / 2
    elif operator=="Sobel":
        for i in range(height - 1):
            for j in range(width):
                P[i * width + j] = float((int(object2[max(i-1,0), min(j + 1, width - 1)])+2*int(object2[i, min(j + 1, width - 1)])+int(object2[min(i+1,height-1), min(j + 1, width - 1)]))
                - (int(object2[max(i-1,0), max(j-1,0)]) + 2*int(object2[i, max(j-1,0)])+int(object2[min(i + 1, height - 1), max(j-1,0)])))
                Q[i * width + j] = float((int(object2[max(i-1,0), max(j-1,0)]) + 2*int(object2[max(i-1,0), j])+int(object2[max(i-1,0), min(j + 1, width - 1)])) -(int(object2[min(i + 1, height - 1), max(j-1,0)])+2*int(object2[min(i + 1, height - 1), j])+int(object2[min(i + 1, height - 1),min(j + 1, width - 1)])))
    else:
        for i in range(height - 1):
            for j in range(width):
                P[i * width + j] = float((int(object2[max(i-1,0), min(j + 1, width - 1)])+int(object2[i, min(j + 1, width - 1)])+int(object2[min(i+1,height-1), min(j + 1, width - 1)]))
                - (int(object2[max(i-1,0), max(j-1,0)]) + int(object2[i, max(j-1,0)])+int(object2[min(i + 1, height - 1), max(j-1,0)])))
                Q[i * width + j] = float((int(object2[max(i-1,0), max(j-1,0)]) + int(object2[max(i-1,0), j])+int(object2[max(i-1,0), min(j + 1, width - 1)])) -(int(object2[min(i + 1, height - 1), max(j-1,0)])+int(object2[min(i + 1, height - 1), j])+int(object2[min(i + 1, height - 1),min(j + 1, width - 1)])))
    for i in range(height):
        for j in range(width):
            M[i * width + j] = int(sqrt(P[i * width + j] ** 2 + Q[i * width + j] ** 2) + 0.5)
            angle[i * width + j] = atan2(Q[i * width + j], P[i * width + j]) * 57.3
            if angle[i * width + j] < 0:
                angle[i * width + j] += 360
    return P,Q,M,angle

def my_NMS(object1,object2,object3,P,Q):
    img = cv2.imread(object1, 0)
    height, width = img.shape[:2]
    area = width * height
    tmp_img= [0] * area
    for i in range(width):
        tmp_img[i] = 0
        tmp_img[(height - 1) * width + i] = 0
    for j in range(height):
        tmp_img[j * width] = 0
        tmp_img[j * width + (width - 1)] = 0
    for i in range(1, width - 1):
        for j in range(1, height - 1):
            index = i + j * width
            if object2[index] == 0:
                tmp_img[index] = 0
            else:
                if ((object3[index] >= 90) and (object3[index] < 135)) or (
                            (object3[index] >= 270) and (object3[index] < 315)):
                    g1 = object2[index - width - 1]
                    g2 = object2[index - width]
                    g3 = object2[index + width]
                    g4 = object2[index + width + 1]
                    dWeight = fabs(P[index]) / fabs(Q[index])
                    dTmp1 = float(g1) * dWeight + float(g2) * (1.0 - dWeight)
                    dTmp2 = float(g4) * dWeight + float(g3) * (1.0 - dWeight)
                elif ((object3[index] >= 135) and (object3[index] < 180)) or (
                            (object3[index] >= 315) and (object3[index] < 360)):
                    g1 = object2[index - width - 1]
                    g2 = object2[index - 1]
                    g3 = object2[index + 1]
                    g4 = object2[index + width + 1]
                    dWeight = fabs(Q[index]) / fabs(P[index])
                    dTmp1 = float(g2) * dWeight + float(g1) * (1.0 - dWeight)
                    dTmp2 = float(g4) * dWeight + float(g3) * (1.0 - dWeight)
                elif ((object3[index] >= 45) and (object3[index] < 90)) or (
                            (object3[index] >= 225) and (object3[index] < 270)):
                    g1 = object2[index - width]
                    g2 = object2[index - width + 1]
                    g3 = object2[index + width]
                    g4 = object2[index + width - 1]
                    dWeight = fabs(P[index]) / fabs(Q[index])
                    dTmp1 = float(g2) * dWeight + float(g1) * (1.0 - dWeight)
                    dTmp2 = float(g3) * dWeight + float(g4) * (1.0 - dWeight)
                elif ((object3[index] >= 0) and (object3[index] < 45)) or (
                            (object3[index] >= 180) and (object3[index] < 225)):
                    g1 = object2[index - width + 1]
                    g2 = object2[index + 1]
                    g3 = object2[index + width - 1]
                    g4 = object2[index - 1]
                    dWeight = fabs(Q[index]) / fabs(P[index])
                    dTmp1 = float(g1) * dWeight + float(g2) * (1.0 - dWeight)
                    dTmp2 = float(g3) * dWeight + float(g4) * (1.0 - dWeight)
            if (object2[index] >= dTmp1) and (object2[index] >= dTmp2):
                tmp_img[index] = 128
            else:
                tmp_img[index] = 0
    return tmp_img

def findedge(y,x,low,tmp_img,M,width):
    xNum = [1, 1, 0, -1, -1, -1, 0, 1]
    yNum = [0, 1, 1, 1, 0, -1, -1, -1]
    for k in range(8):
        xx = x + xNum[k]
        yy = y + yNum[k]
        if tmp_img[yy * width + xx] == 128 and M[yy * width + xx] >= low:
            tmp_img[yy * width + xx] = 255
            findedge(yy, xx,low,tmp_img,M,width)
def threshold_value_connect(object,img,tmp_img,M,high,low):
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]
    for i in range(height):
        for j in range(width):
            if (tmp_img[i * width + j] == 128) and (M[i * width + j] >= high):
                tmp_img[i * width + j] = 255
                findedge(i, j, low, tmp_img, M, width)
    for i in range(height):
        for j in range(width):
            if tmp_img[i * width + j] != 255:
                tmp_img[i * width + j] = 0
    for i in range(height):
        for j in range(width):
            img[i, j] = tmp_img[i * width + j]
    return img

def my_final_result(object,operator):#采用自适应算法求阈值
    img=graying(object)
    img=my_Gaussian_Blur(object,img)
    P,Q,M,angle=calculation(object,img,operator)
    tmp_img=my_NMS(object,M,angle,P,Q)
    high,low=find_value(object,M,tmp_img)
    img=threshold_value_connect(object,img,tmp_img,M,high,low)
    return img

def my_final_result_origin(object,high,low,operator):#采用自适应算法求阈值
    img=graying(object)
    img=my_Gaussian_Blur(object,img)
    P,Q,M,angle=calculation(object,img,operator)
    tmp_img=my_NMS(object,M,angle,P,Q)
    img=threshold_value_connect(object,img,tmp_img,M,high,low)
    return img


def canny_final_result(object,high,low):
    img = cv2.imread(object, 0)
    canny_img=cv2.Canny(img,high,low)
    return canny_img

def my_canny(object,operator):
    img=my_final_result(object,operator)
    cv2.imshow("My Canny", img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def my_canny_origin(object,high,low,operator):
    img=my_final_result_origin(object,high,low,operator)
    cv2.imshow("My Canny", img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def opencv_canny(object,high,low):
    canny_img=canny_final_result(object,high,low)
    cv2.imshow("Opencv Canny", canny_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
def compare_canny(object,high,low,operator):
    my_img=my_final_result_origin(object,high,low,operator)
    canny_img=canny_final_result(object,high,low)
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]
    area=height*width
    TP=0
    FP=0
    TN=0
    FN=0
    for i in range(height):
        for j in range(width):
            if my_img[i,j]==canny_img[i,j]:
                if my_img[i,j]==255:
                    TP+=1
                else:
                    FN+=1
            else:
                if my_img[i,j]==255:
                    TN+=1
                else:
                    FP+=1
    accuracy=float(TP+FN)/area
    print "The percentage of TP:%s"%(float(TP)/area)
    print "The percentage of FP:%s"%(float(FP)/area)
    print "The percentage of TN:%s"%(float(TN)/area)
    print "The percentage of FN:%s"%(float(FN)/area)
    print "Accuracy:%s"%(accuracy)

def find_value(object,M,tmp_img):#自适应算法求阈值
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]

    parameter1 = 0.6
    parameter2 = 0.5
    
    distribution = [0] * 1024
    max_M = 0
    num = 0

    for i in range(height):
        for j in range(width):
            if tmp_img[i * width + j] == 128:
                distribution[int(M[i * width + j])] += 1

    edge = distribution[0]
    for i in range(1024):
        if distribution[i] != 0:
            max_M = i
        edge += distribution[i]

    num = int(parameter1 * edge + 0.5)

    j = 1
    edge = distribution[1]
    while (j < (max_M - 1)) and (edge < num):
        j += 1
        edge += distribution[j]
    high = j
    low = int((high) * parameter2 + 0.5)

    print "High:",high
    print "Low:",low
    return high,low


img1 = "1.jpg"
img2 = "2.jpg"
img3 = "3.jpg"
Sobel="Sobel"
Prewitt="Prewitt"
Canny="Canny"




my_canny(img1,Canny)#采用自适应算法推算合适阈值后，就无需再手动输入并传入阈值参数了

#采用自适应算法后，很多函数就少了两个参数，例如compare_canny(img1,high,low,Canny)函数是在人为规定双阈值的情况下进行比较，所以再调用该函数时，其内部调用的函数需要稍作修改，补回双阈值参数
#函数名带有origin的表示为未采用自适应算法求阈值的原来的函数

'''high=30
low=10
my_canny_origin(img1,high,low,Canny)
opencv_canny(img1,high,low)
compare_canny(img1,high,low,Canny)'''




