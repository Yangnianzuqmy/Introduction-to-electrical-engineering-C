# coding=utf-8

import cv2
import numpy as np
import matplotlib.pyplot as plt
import math





#灰度化
def graying(object):
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]
    img2 = cv2.imread(object, cv2.IMREAD_COLOR)
    for i in range(height):
        for j in range(width):
            img[i, j] = 0.114 * int(img2[i, j][0]) + 0.587 * int(img2[i, j][1]) + 0.299 * int(img2[i, j][2])
    return img

#求所有的梯度和方向角
def calculation(object,tmp_img,m):
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]
    area = width * height
    P = [0] * area
    Q = [0] * area
    M = [0] * area
    angle = [0] * area
    for i in range(height - 1):
        for j in range(width):
            P[i * width + j] = float(int(img[min(i+1,height-1),j]) - int(img[max(i-1,0),j]))
            Q[i * width + j] = float(int(img[i,min(j+1,width-1)]) - int(img[i,max(j-1,0)]))
    for i in range(height-1):
        for j in range(width):
            M[i * width + j] = int(math.sqrt(P[i * width + j] ** 2 + Q[i * width + j] ** 2) + 0.5)
            angle[i * width + j] = math.atan2(Q[i * width + j], P[i * width + j])*57.3
            while angle[i * width + j] < 0:
                angle[i * width + j] += 360
    return M,angle

def futher_calculation(object,M,angle,m,corners):#计算关键点主方向
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]
    area=m*m
    radius=(m-1)//2
    part_M=[]
    part_angle=[]
    main_direction=[]
    for i in range(len(corners)):
        position=0
        tmp_M=[0]*area
        tmp_angle=[0]*area
        x, y = corners[i].ravel()
        for j in range(y-radius,y+radius+1):
            for k in range(x-radius,x+radius+1):
                tmp_M[position]=M[j*width+k]
                tmp_angle[position]=angle[j*width+k]
                position+=1
        part_M.append(tmp_M)
        part_angle.append(tmp_angle)
    for i in range(len(corners)):
        direction_divide=[0]*36
        for j in range(len(part_M)):
            for k in range(area):
                direction_divide[int(part_angle[i][k]//10)]+=part_M[i][k]*part_angle[i][k]
        main_direction.append(direction_divide.index(max(direction_divide))*10)
    return main_direction

def direction_object_coordinate(object,corners,main_direction,M,angle):
    img = cv2.imread(object, 0)
    height, width = img.shape[:2]
    new_M=[]
    new_direcition=[]
    for i in range(len(main_direction)):
        tmp_angle_list=[]
        tmp_m_list=[]
        x, y = corners[i].ravel()
        step1=math.cos(main_direction[i]/180*math.pi)
        step2=math.sin(main_direction[i]/180*math.pi)
        for j in range(-7,9):
            for k in range(-7,9):
                tmp_x=x+step1*k
                tmp_y=y+step2*j
                xx=int(tmp_x)
                yy=int(tmp_y)
                dx=tmp_x-xx
                dy=tmp_y-yy
                tmp_angle=angle[min((y+j),height-1)*width+min(x+k,width)]*(1-dx)*(1-dy)+angle[min((y+j),height-1)*width+min(x+k+1,width)]*dx*(1-dy)+\
                          angle[min((y+j+1),height-1)*width+min(x+k,width)]*(1-dx)*dy+angle[min((y+j+1),height-1)*width+min(x+k+1,width)]*dx*dy
                tmp_m=M[min((y+j),height-1)*width+min(x+k,width)]*(1-dx)*(1-dy)+M[min((y+j),height-1)*width+min(x+k+1,width)]*dx*(1-dy)\
                      +M[min((y+j+1),height-1)*width+min(x+k,width)]*(1-dx)*dy+M[min((y+j+1),height-1)*width+min(x+k+1,width)]*dx*dy
                tmp_result=tmp_angle-main_direction[i]
                if tmp_result<0:
                    tmp_angle_list.append(tmp_result+360)
                else:
                    tmp_angle_list.append(tmp_result)
                tmp_m_list.append(tmp_m)
        new_direcition.append(tmp_angle_list)
        new_M.append(tmp_m_list)
    return new_M,new_direcition

def sift_description(corners,new_M,new_direction):
    sift_vector=[]
    for i in range(len(corners)):
        tmp_vector=[]
        for j in range(4):
            for k in range(4):
                division=[0]*8
                start_row=j*4
                start_line=k*4
                for m in range(start_row,start_row+4):
                    for n in range(start_line,start_line+4):
                        division[min(int(new_direction[i][m*16+n]//45),7)]+=new_M[i][m*16+n]*new_direction[i][m*16+n]
                tmp_vector.append(division)
        sift_vector.append(tmp_vector)
    return sift_vector

def uniform(sift_vector):
    for i in range(len(sift_vector)):
        sum=0
        for j in range(16):
            for k in range(8):
                sum+=sift_vector[i][j][k]**2
        sum=math.sqrt(sum)
        for j in range(16):
            for k in range(8):
                sift_vector[i][j][k]/=sum
    return sift_vector


def extract_character(imgname):
    img = cv2.imread(imgname)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    corners = cv2.goodFeaturesToTrack(gray, maxCorners=10, qualityLevel=0.01, minDistance=20)
    corners = np.int0(corners)
    tmp_img = graying(imgname)
    M,angle=calculation(imgname,tmp_img,3)
    main_direction=futher_calculation(imgname,M,angle,3,corners)
    new_M,new_direction=direction_object_coordinate(imgname,corners,main_direction,M,angle)
    sift_vector=sift_description(corners,new_M,new_direction)
    sift_vector=uniform(sift_vector)
    return sift_vector

def compare_method1(target,sample):#用PPI中方法以描述子乘积作为指标
    threshold=0.5
    sift_target=extract_character(target)
    sift_sample=[]
    goal=[0]*len(sample)
    pair=[]
    for i in range(len(sample)):
        sift_sample.append(extract_character(sample[i]))
    for i in range(len(sample)):
        tmp_pair=[]
        for h in range(len(sift_target)):
            for m in range(len(sift_target)):
                sum=0
                for j in range(16):
                    for k in range(8):
                        sum+=sift_target[h][j][k]*sift_sample[i][m][j][k]
                if (sum>threshold):
                    goal[i]+=1
                    tmp_pair.append([h,m])
        pair.append(tmp_pair)
    position=goal.index(max(goal))
    print("相似度最高的图片为：%s"%(sample[position]))
    return position,pair[position]

def compare_method2(target,sample):#以描述子差值的模的大小作为指标
    threshold=0.9
    sift_target=extract_character(target)
    sift_sample=[]
    difference=[]
    goal=[0]*len(sample)
    pair=[]
    for i in range(len(sample)):
        sift_sample.append(extract_character(sample[i]))
    for i in range(len(sample)):
        tmp_pair=[]
        for h in range(len(sift_target)):
            for m in range(len(sift_target)):
                sum=0.0
                for j in range(16):
                    for k in range(8):
                        sum+=(sift_target[h][j][k]-sift_sample[i][h][j][k])**2
                if (sum<threshold):
                    goal[i]+=1
                    tmp_pair.append([h,m])
        pair.append(tmp_pair)
    position=goal.index(max(goal))
    print("相似度最高的图片为：%s"%(sample[position]))
    return position,pair[position]

def draw_line(target,result,pair):
    img1 = cv2.imread(target, cv2.IMREAD_COLOR)
    height1, width1 = img1.shape[:2]
    img2 = cv2.imread(result, cv2.IMREAD_COLOR)
    height2, width2 = img2.shape[:2]
    height=max(height1,height2)
    width=width1+width2
    tmp_show=np.array([[[255 for k in range(3)]for j in range(width)]for i in range(height)])
    for i in range(height1):
        for j in range(width1):
            tmp_show[i][j]=img1[i][j]
            tmp=img1[i][j][2]
            tmp_show[i][j][2]=img1[i][j][0]
            tmp_show[i][j][0]=tmp
    for i in range(height2):
        for j in range(width2):
            tmp_show[i][j+width1]=img1[i][j]
            tmp=img2[i][j][2]
            tmp_show[i][j+width1][2]=img2[i][j][0]
            tmp_show[i][j+width1][0]=tmp
    img11= cv2.imread(target)
    gray = cv2.cvtColor(img11, cv2.COLOR_BGR2GRAY)
    corners1= cv2.goodFeaturesToTrack(gray, maxCorners=10, qualityLevel=0.01, minDistance=20)
    corners1 = np.int0(corners1)
    img22= cv2.imread(result)
    gray = cv2.cvtColor(img22, cv2.COLOR_BGR2GRAY)
    corners2= cv2.goodFeaturesToTrack(gray, maxCorners=10, qualityLevel=0.01, minDistance=20)
    corners2 = np.int0(corners2)
    for i in range(min(len(pair),8)):
        x1,y1=corners1[pair[i][0]].ravel()
        x2,y2=corners2[pair[i][1]].ravel()
        cv2.line(tmp_show,(int(x1),int(y1)),(int(x2)+width1,int(y2)),(0,255,0),5)
    plt.imshow(tmp_show)
    plt.show()


target='target.jpg'
sample=['dataset\\1.jpg','dataset\\2.jpg','dataset\\3.jpg','dataset\\4.jpg','dataset\\5.jpg']




compare_method1(target,sample)




