# coding=utf-8

import cv2
import numpy as np
import matplotlib.pyplot as plt
import math
import random
import os
import time


def get_des(imgname):#该函数用来获得描述子
    orb = cv2.ORB_create()
    img = cv2.imread(imgname,0)
    kp, des = orb.detectAndCompute(img, None)
    return des

def get_chara_vector(imgname):#得到特征向量
    img = cv2.imread(imgname,cv2.IMREAD_COLOR)
    height, width = img.shape[:2]
    mid_height=height//2
    mid_width=width//2
    H=[0 for i in range(12)]
    p=[]
    for i in range(mid_height):#统计四大块
        for j in range(mid_width):
            H[0]+=img[i][j][0]
            H[1]+=img[i][j][1]
            H[2]+=img[i][j][2]
    for i in range(mid_height):
        for j in range(mid_width,width):
            H[3]+=img[i][j][0]
            H[4]+=img[i][j][1]
            H[5]+=img[i][j][2]
    for i in range(mid_height,height):
        for j in range(mid_width):
            H[6]+=img[i][j][0]
            H[7]+=img[i][j][1]
            H[8]+=img[i][j][2]
    for i in range(mid_height,height):
        for j in range(mid_width,width):
            H[9]+=img[i][j][0]
            H[10]+=img[i][j][1]
            H[11]+=img[i][j][2]
    for i in range(4):
        sum=0.0
        sum+=float(H[i*3])+float(H[i*3+1])+float(H[i*3+2])
        p.append(H[i*3]/sum)
        p.append(H[i*3+1]/sum)
        p.append(H[i*3+2]/sum)
    for i in range(12):
        if p[i]<0.3:
            p[i]=0
        elif p[i]>=0.3 and p[i]<0.4:
            p[i]=1
        else:
            p[i]=2
    return p

def LSH_pre_method1(p,subset):#LSH预处理 用法一
    tmp_str=''
    projection=''
    for i in range(12):
        if p[i]==0:
            tmp_str+='00'
        elif p[i]==1:
            tmp_str+='10'
        else:
            tmp_str+='11'
    for i in range(len(subset)):
        projection+=tmp_str[subset[i]]
    return projection

def LSH_pre_method2(p,subset):#LSH预处理 用法二
    projection=''
    for i in range(12):
        tmp=[]# 存放范围在(i-1)*C+1~i*C中的坐标
        start=i*2+1
        end=(i+1)*2
        for j in range(len(subset)):
            if subset[j]+1>start-1 and subset[j]+1<end+1:
                tmp.append(subset[j]+1)
        for j in range(len(tmp)):
            if tmp[j]-2*i<=p[i]:
                projection+='1'
            else:
                projection+='0'
    return projection

def subset(num):#用以随机生成投影集合
    subset=[]
    while (len(subset)<num):
        x = random.randint(0,23)
        if x not in subset:
            subset.append(x)
    subset.sort()
    return subset

def LSH_preparation(subset):
    print("投影集合为:%s"%(subset))
    vector_list=[]
    rootdir = 'Dataset'
    list = os.listdir(rootdir)  # 列出文件夹下所有的目录与文件
    for i in range(0, len(list)):#提取出所有图片的特征向量
        path = os.path.join(rootdir, list[i])
        if os.path.isfile(path):
            p = get_chara_vector(path)
            vector_list.append([p,path.split('\\')[-1]])

    projection_list=[]
    for i in range(len(vector_list)):#求出每个图片的hamming码
        projection_list.append([LSH_pre_method1(vector_list[i][0],subset),vector_list[i][1]])

    #将图片分堆
    pocket_mark=[]#存放每个堆的标志
    pocket_index=[]#对应标志列表 存放每个堆有哪些元素
    index=0
    for i in range(len(projection_list)):
        if projection_list[i][0] not in pocket_mark:
            pocket_mark.append(projection_list[i][0])
            pocket_index.append([])
            index+=1
            pocket_index[pocket_mark.index(projection_list[i][0])].append(projection_list[i][1])
        else:
            pocket_index[pocket_mark.index(projection_list[i][0])].append(projection_list[i][1])
    return pocket_mark,pocket_index

def LSH(num):
    sub_set=subset(num)
    pocket_mark,pocket_index=LSH_preparation(sub_set)
    p_target=get_chara_vector('target.jpg')
    ham_target=LSH_pre_method1(p_target,sub_set)

    index=pocket_mark.index(ham_target)
    error=[]

    vector_target=get_chara_vector('target.jpg')
    vector_sample_list=[]
    for i in range(len(pocket_index[index])):
        sample_name='Dataset\\'+pocket_index[index][i]
        vector_sample=get_chara_vector(sample_name)
        vector_sample_list.append(vector_sample)
    start_time=time.time()
    for j in range(10000):
        error = []
        for i in range(len(vector_sample_list)):
            error.append(evaluate_similarity(vector_target,vector_sample_list[i]))
        result=pocket_index[index][error.index(min(error))]
    end_time=time.time()
    print('LSH:')
    print('Time cost:%s'%(end_time-start_time))
    print('匹配结果：%s'%(result))



def evaluate_similarity(vector_target,vector_sample):
    sum=0.0
    for i in range(len(vector_target)):
        sum+=(vector_target[i]-vector_sample[i])**2
    return sum

def NN():
    vector_list=[]
    rootdir = 'Dataset'
    list = os.listdir(rootdir)  # 列出文件夹下所有的目录与文件
    for i in range(0, len(list)):#提取出所有图片的特征向量
        path = os.path.join(rootdir, list[i])
        if os.path.isfile(path):
            p = get_chara_vector(path)
            vector_list.append([p,path.split('\\')[-1]])
    vector_target=get_chara_vector('target.jpg')
    error=[]
    start_time=time.time()
    for i in range(10000):
        error=[]
        for i in range(len(vector_list)):
            error.append(evaluate_similarity(vector_target,vector_list[i][0]))
        result=vector_list[error.index(min(error))][1]
    end_time=time.time()
    print('NN:')
    print('Time cost:%s'%(end_time-start_time))
    print('匹配结果：%s'%(result))


def get_des(imgname):#该函数用来获得描述子
    orb = cv2.ORB_create()
    img = cv2.imread(imgname,0)
    kp, des = orb.detectAndCompute(img, None)
    return des

def evaluate_similarity_alternative(des_target,des_sample):
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = bf.match(des_target, des_sample)
    return len(matches)

def NN_2():#采用PPT中提供函数的NN搜索方法
    rootdir = 'Dataset'
    des_list=[]
    list = os.listdir(rootdir)  # 列出文件夹下所有的目录与文件
    for i in range(0, len(list)):
        path = os.path.join(rootdir, list[i])
        if os.path.isfile(path):
            des_list.append([get_des(path),path.split('\\')[-1]])
    error=[]
    des_target = get_des('target.jpg')
    for i in range(len(des_list)):
        sample_name = 'Dataset\\' + str(des_list[i][1])
        des_sample = get_des(sample_name)
        error.append(evaluate_similarity_alternative(des_target, des_sample))
    print('Searching Result:%s'%(des_list[error.index(max(error))][1]))



LSH(5)
NN()
#NN_2()