# -*- coding: utf8 -*-
import time
class Bitarray:
    def __init__(self, size):
        """ Create a bit array of a specific size """
        self.size = size
        self.bitarray = bytearray(size/8)

    def set(self, n):
        """ Sets the nth element of the bitarray """

        index = n / 8
        position = n % 8
        self.bitarray[index] = self.bitarray[index] | 1 << (7 - position)

    def get(self, n):
        """ Gets the nth element of the bitarray """

        index = n / 8
        position = n % 8
        return (self.bitarray[index] & (1 << (7 - position))) > 0


def BKDRHash(key,seed,num):
    hash = 0
    for i in range(len(key)):
        hash = (hash * seed ) + ord(key[i])
    return hash % num

def file_open(filename):
    words = []
    f = open(filename, 'r')
    for line in f.xreadlines():
        for word in line.strip().split(' '):
            words.append(word)
    f.close()
    words_set=[]
    for i in words:
        if not i in words_set:
            words_set.append(i)
    return words_set


def hash(words):
    bitarray= [Bitarray(len(words)*20)]*10
    false_positive = 0
    for i in words:
        flag = True
        seed = [3,5,13,31,131,1313,13131,131313,1313131,13131313,131313131,1313131313]
        for j in range(10):
            if bitarray[j].get(BKDRHash(i, seed[j],len(words)*20))==0:
                flag = False
                break
        if not flag:
            for j in range(10):
                bitarray[j].set(BKDRHash(i, seed[j],len(words)*20))
        if flag:
            false_positive+=1
    return false_positive,len(words)

if __name__ == "__main__":
    filename = "pg1661.txt"
    words= file_open(filename)
    false_positive,total= hash(words)
    print "total:" ,total
    print"false postive:",false_positive
    print "false positive rate:",float(false_positive)/total