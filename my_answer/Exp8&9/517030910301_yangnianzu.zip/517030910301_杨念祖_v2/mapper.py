#!/usr/bin/env python

import sys

output=""

for line in sys.stdin:
    line = line.strip()
    if (len(line)>0):
	    words = line.split()
	    total=len(words)
	    if total==2:
		output+=(str(words[0])+'\t'+words[1]+'\n')
	    else:
		output+=(str(words[0])+'\t'+words[1]+'\t')
		for i in range(2,total-1):
		    output+=words[i]+'\t'
		output+=words[total-1]+'\n'
print output
