#!/usr/bin/env python

import sys

# input comes from STDIN (standard input)

initial_letter=[]
initial_letter_index=[]
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # split the line into words
    words = line.split()
    # increase counters
    for i in range(len(words)):
        if words[i][0].lower() not in initial_letter:
            initial_letter.append(words[i][0].lower())
            initial_letter_index.append([words[i][0].lower(),1,len(words[i])])
        else:
            a=initial_letter.index(words[i][0].lower())
            initial_letter_index[a][1]+=1
            initial_letter_index[a][2]+=len(words[i])

for i in range(len(initial_letter_index)):
    print '%s\t%s' % (initial_letter_index[i][0],float(initial_letter_index[i][2])/initial_letter_index[i][1])
