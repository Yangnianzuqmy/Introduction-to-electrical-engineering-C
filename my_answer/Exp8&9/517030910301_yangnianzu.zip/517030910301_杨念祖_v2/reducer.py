#!/usr/bin/env python
# -*- coding: utf8 -*-
import sys


weight=[]
outlinks=[]
pagerank=[]
word=[]

for line in sys.stdin:
    line = line.strip()
    if (len(line)>0):
        word.append(line)

num=len(word)
for i in range(num):
    word[i]=word[i].split()
    tmp=[]
    for j in range(2,len(word[i])):
        tmp.append(word[i][j])
    outlinks.append(tmp)


for i in range(num):
    pagerank.append(float(word[i][1]))
    weight_tmp=[]
    for j in range(num):
        if word[i][0] not in outlinks[j]:
            weight_tmp.append(0)
        else:
            weight_tmp.append(float(1)/len(outlinks[j]))
    weight.append(weight_tmp)


pagerank_result=[]
for i in range(num):
    sum=0
    for j in range(num):
        sum+=float(weight[i][j])*pagerank[j]
    pagerank_result.append(0.85*sum+0.15/num)

output=""
for i in range(num):
    if len(word[i])==2:
        output+=str(word[i][0])+'\t'+str(pagerank_result[i])+'\n'
    else:
        output+=str(word[i][0])+'\t'+str(pagerank_result[i])+'\t'
        for j in range(2,len(word[i])-1):
            output+=word[i][j]+'\t'
        output+=str(word[i][len(word[i])-1])+'\n'

print output
